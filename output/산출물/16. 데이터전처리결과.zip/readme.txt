mountainweather : 산악기상정보
sb_true : 산악기상정보와 산불 데이터 inner join 한 데이터. 즉 산불이 일어났을 때의 기상정보 (sanbul=1)
sb_false : sanbul=0 의 산악 기상정보